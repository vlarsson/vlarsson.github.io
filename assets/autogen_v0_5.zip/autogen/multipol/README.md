# multipol
Matlab toolbox for systems of polynomial equations
