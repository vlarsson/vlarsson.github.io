function e = ne(p1, p2)
e = ~(p1 == p2);