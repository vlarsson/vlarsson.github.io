function r = le(p1,p2)
r = ~(p1>p2);