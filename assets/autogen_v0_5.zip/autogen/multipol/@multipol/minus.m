function p3 = minus(p1,p2)
% MULTIPOL/MINUS operator
% Subtraction of two polynomial or one of them can be a double.  
% p3 = minus(p1,p2);
% p3 = p1-p2;
p3 = p1 + (-p2);