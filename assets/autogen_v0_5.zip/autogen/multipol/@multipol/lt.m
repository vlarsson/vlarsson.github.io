function r = lt(p1,p2)
r = ~(p1>=p2);